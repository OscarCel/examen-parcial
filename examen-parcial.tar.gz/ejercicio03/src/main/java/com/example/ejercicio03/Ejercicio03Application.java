package com.example.ejercicio03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio03Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio03Application.class, args);
	}

}
