package com.example.ejercicio01.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ejercicio01.model.Armario;
import com.example.ejercicio01.model.Cama;
import com.example.ejercicio01.model.Coche;
import com.example.ejercicio01.model.ConPuertas;
import com.example.ejercicio01.model.Mueble;

@RestController
@RequestMapping("/api/muebles")
public class MuebleController {

    //para probarlo ejecutalo y escrube esto en un buscado: http://localhost:8080/api/muebles/mostrar
    @GetMapping("/mostrar")
    public String mostrarMuebles() {
        Mueble armario = new Armario("Armario Grande");
        Mueble cama = new Cama("Cama Queen");
        Coche coche = new Coche("Coche Deportivo");

        StringBuilder sb = new StringBuilder();
        sb.append(armario.descripcion()).append("\n");
        sb.append(cama.descripcion()).append("\n");
        sb.append(coche.descripcion()).append("\n");

        if (armario instanceof ConPuertas) {
            ConPuertas armarioConPuertas = (ConPuertas) armario;
            armarioConPuertas.abrirPuertas();
            sb.append("Estado del armario: ").append(armarioConPuertas.estadoPuertas()).append("\n");
            armarioConPuertas.cerrarPuertas();
            sb.append("Estado del armario después de cerrar: ").append(armarioConPuertas.estadoPuertas()).append("\n");
        }

        if (coche instanceof ConPuertas) {
            ConPuertas cocheConPuertas = (ConPuertas) coche;
            cocheConPuertas.abrirPuertas();
            sb.append("Estado del coche: ").append(cocheConPuertas.estadoPuertas()).append("\n");
            cocheConPuertas.cerrarPuertas();
            sb.append("Estado del coche después de cerrar: ").append(cocheConPuertas.estadoPuertas()).append("\n");
        }

        return sb.toString();
    }
}

