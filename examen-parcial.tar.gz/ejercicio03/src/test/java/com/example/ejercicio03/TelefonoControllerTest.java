package com.example.ejercicio03;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.example.ejercicio03.controller.TelefonoController;
import com.example.ejercicio03.model.Teclado;
import com.example.ejercicio03.model.Pantalla;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@WebMvcTest(TelefonoController.class)
public class TelefonoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private Teclado teclado;

    @MockBean
    private Pantalla pantalla;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(pantalla.mostrar()).thenReturn("Pantalla actualizada");
    }

    @Test
    void testEncenderApagar() throws Exception {
        doNothing().when(teclado).EncenderApagar(anyString());

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/telefono/encender-apagar"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().string("Pantalla actualizada"))
                .andReturn();

        assertEquals("Pantalla actualizada", mvcResult.getResponse().getContentAsString());
        verify(teclado).EncenderApagar("Power");
    }

    @Test
    void testLlamarColgar() throws Exception {
        doNothing().when(teclado).LlamarColgar(anyString());

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/telefono/llamar-colgar")
                .param("accion", "Llamar"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().string("Pantalla actualizada"))
                .andReturn();

        assertEquals("Pantalla actualizada", mvcResult.getResponse().getContentAsString());
        verify(teclado).LlamarColgar("Llamar");
    }

    @Test
    void testEstado() throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/telefono/estado"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().string("Pantalla actualizada"))
                .andReturn();

        assertEquals("Pantalla actualizada", mvcResult.getResponse().getContentAsString());
    }
}
