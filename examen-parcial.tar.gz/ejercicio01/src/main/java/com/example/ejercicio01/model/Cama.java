package com.example.ejercicio01.model;

public class Cama extends Mueble {
    public Cama(String nombre) {
        super(nombre);
    }

    @Override
    public String descripcion() {
        return "Cama: " + getNombre();
    }
}
