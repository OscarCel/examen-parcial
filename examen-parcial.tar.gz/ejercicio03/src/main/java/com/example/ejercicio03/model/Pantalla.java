package com.example.ejercicio03.model;

public class Pantalla {
    private Telefono telefono;

    public Pantalla(Telefono telefono) {
        this.telefono = telefono;
    }

    public String mostrar() {
        if (telefono.isEncendido() && telefono.isEnLlamada()) {
            return "Llamando al número: " + telefono.getNumeroActual();
        } else if (telefono.isEncendido()) {
            return "Número marcado: " + telefono.getNumeroActual();
        } else {
            return "Teléfono apagado";
        }
    }
}

