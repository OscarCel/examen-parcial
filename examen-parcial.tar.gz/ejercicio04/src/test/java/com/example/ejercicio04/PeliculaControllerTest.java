package com.example.ejercicio04;

import com.example.ejercicio04.model.Director;
import com.example.ejercicio04.model.Pelicula;
import com.example.ejercicio04.service.PeliculaService;
import com.example.ejercicio04.service.DirectorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PeliculaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private PeliculaService peliculaService;

    @Autowired
    private DirectorService directorService;

    @Test
    void testListarPeliculas() throws Exception {
        mockMvc.perform(get("/peliculas"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(greaterThanOrEqualTo(0))));
    }

    @Test
    void testLeerPelicula() throws Exception {
        Director director = new Director();
        director.setNombre("Director Test");
        director.setNacimiento(1965);
        director = directorService.crearDirector(director);

        Pelicula pelicula = new Pelicula();
        pelicula.setTitulo("Pelicula Test");
        pelicula.setLanzamiento(2020);
        pelicula.setDirector(director);
        pelicula = peliculaService.crearPelicula(pelicula);

        mockMvc.perform(get("/peliculas/{id}", pelicula.getId()))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id", is(pelicula.getId().intValue())))
                .andExpect(jsonPath("$.titulo", is(pelicula.getTitulo())))
                .andExpect(jsonPath("$.lanzamiento", is(pelicula.getLanzamiento())))
                .andExpect(jsonPath("$.director.id", is(director.getId().intValue())));
    }

    @Test
    void testCrearPelicula() throws Exception {
        Director director = new Director();
        director.setNombre("Director Nuevo");
        director.setNacimiento(1970);
        director = directorService.crearDirector(director);

        String peliculaJson = String.format("{\"titulo\": \"Nueva Pelicula\", \"lanzamiento\": 2022, \"director\": {\"id\": %d}}", director.getId());

        mockMvc.perform(post("/peliculas")
                .contentType(MediaType.APPLICATION_JSON)
                .content(peliculaJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", notNullValue()))
                .andExpect(jsonPath("$.titulo", is("Nueva Pelicula")))
                .andExpect(jsonPath("$.lanzamiento", is(2022)))
                .andExpect(jsonPath("$.director.id", is(director.getId().intValue())));
    }

    @Test
    void testActualizarPelicula() throws Exception {
        Director director = new Director();
        director.setNombre("Director Existente");
        director.setNacimiento(1975);
        director = directorService.crearDirector(director);

        Pelicula pelicula = new Pelicula();
        pelicula.setTitulo("Pelicula Existente");
        pelicula.setLanzamiento(2010);
        pelicula.setDirector(director);
        pelicula = peliculaService.crearPelicula(pelicula);

        String peliculaActualizadaJson = String.format("{\"titulo\": \"Pelicula Actualizada\", \"lanzamiento\": 2011, \"director\": {\"id\": %d}}", director.getId());

        mockMvc.perform(put("/peliculas/{id}", pelicula.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(peliculaActualizadaJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(pelicula.getId().intValue())))
                .andExpect(jsonPath("$.titulo", is("Pelicula Actualizada")))
                .andExpect(jsonPath("$.lanzamiento", is(2011)))
                .andExpect(jsonPath("$.director.id", is(director.getId().intValue())));
    }

    @Test
    void testBorrarPelicula() throws Exception {
        Director director = new Director();
        director.setNombre("Director a Borrar");
        director.setNacimiento(1960);
        director = directorService.crearDirector(director);

        Pelicula pelicula = new Pelicula();
        pelicula.setTitulo("Pelicula a Borrar");
        pelicula.setLanzamiento(2000);
        pelicula.setDirector(director);
        pelicula = peliculaService.crearPelicula(pelicula);

        mockMvc.perform(delete("/peliculas/{id}", pelicula.getId()))
                .andExpect(status().isNoContent());
    }
}
