package com.example.ejercicio01.model;

public class Armario extends Mueble implements ConPuertas {
    private boolean puertasAbiertas;

    public Armario(String nombre) {
        super(nombre);
        this.puertasAbiertas = false; // Inicialmente, las puertas están cerradas
    }

    @Override
    public String descripcion() {
        return "Armario: " + getNombre();
    }

    @Override
    public void abrirPuertas() {
        puertasAbiertas = true;
        System.out.println("Puertas del armario abiertas.");
    }

    @Override
    public void cerrarPuertas() {
        puertasAbiertas = false;
        System.out.println("Puertas del armario cerradas.");
    }

    @Override
    public String estadoPuertas() {
        return puertasAbiertas ? "Puertas abiertas" : "Puertas cerradas";
    }
}

