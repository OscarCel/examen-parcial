package com.example.ejercicio01.model;

public abstract class Mueble {
    private String nombre;

    public Mueble(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public abstract String descripcion();
}
