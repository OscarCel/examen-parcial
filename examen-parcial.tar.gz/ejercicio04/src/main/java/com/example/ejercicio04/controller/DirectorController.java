package com.example.ejercicio04.controller;

import com.example.ejercicio04.model.Director;
import com.example.ejercicio04.service.DirectorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/directores")
public class DirectorController {

    @Autowired
    private DirectorService directorService;

    @GetMapping
    public List<Director> listarDirectores() {
        return directorService.listarDirectores();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Director> leerDirector(@PathVariable Long id) {
        Optional<Director> director = directorService.leerDirector(id);
        if (director.isPresent()) {
            return new ResponseEntity<>(director.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Director crearDirector(@Validated @RequestBody Director director) {
        return directorService.crearDirector(director);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Director> actualizarDirector(@PathVariable Long id, @Validated @RequestBody Director director) {
        Optional<Director> updatedDirector = directorService.actualizarDirector(id, director);
        return updatedDirector.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrarDirector(@PathVariable Long id) {
        directorService.borrarDirector(id);
        return ResponseEntity.noContent().build();
    }
}
