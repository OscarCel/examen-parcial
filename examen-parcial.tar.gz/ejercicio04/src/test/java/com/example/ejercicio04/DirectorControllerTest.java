package com.example.ejercicio04;

import com.example.ejercicio04.model.Director;
import com.example.ejercicio04.service.DirectorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class DirectorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private DirectorService directorService;

    @Test
    void testListarDirectores() throws Exception {
        Director director1 = new Director();
        director1.setNombre("Director1");
        director1.setNacimiento(1970);
        directorService.crearDirector(director1);
    
        Director director2 = new Director();
        director2.setNombre("Director2");
        director2.setNacimiento(1980);
        directorService.crearDirector(director2);
    
        mockMvc.perform(get("/directores"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(greaterThanOrEqualTo(2))));
    }

    @Test
    void testLeerDirector() throws Exception {
        Director director = new Director();
        director.setNombre("Director");
        director.setNacimiento(1978);
        director = directorService.crearDirector(director);

        mockMvc.perform(get("/directores/{id}", director.getId()))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id", is(director.getId().intValue())))
                .andExpect(jsonPath("$.nombre", is(director.getNombre())))
                .andExpect(jsonPath("$.nacimiento", is(director.getNacimiento())));
    }

    @Test
    void testCrearDirector() throws Exception {
        String directorJson = "{\"nombre\": \"Nuevo Director\", \"nacimiento\": 1980}";

        mockMvc.perform(post("/directores")
                .contentType(MediaType.APPLICATION_JSON)
                .content(directorJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", notNullValue()))
                .andExpect(jsonPath("$.nombre", is("Nuevo Director")))
                .andExpect(jsonPath("$.nacimiento", is(1980)));
    }

    @Test
    void testActualizarDirector() throws Exception {
        Director director = new Director();
        director.setNombre("Director2");
        director.setNacimiento(1974);
        director = directorService.crearDirector(director);

        String directorActualizadoJson = "{\"nombre\": \"Director Actualizado\", \"nacimiento\": 1975}";

        mockMvc.perform(put("/directores/{id}", director.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(directorActualizadoJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(director.getId().intValue())))
                .andExpect(jsonPath("$.nombre", is("Director Actualizado")))
                .andExpect(jsonPath("$.nacimiento", is(1975)));
    }

    @Test
    void testBorrarDirector() throws Exception {
        Director director = new Director();
        director.setNombre("Director a Borrar");
        director.setNacimiento(1960);
        director = directorService.crearDirector(director);

        mockMvc.perform(delete("/directores/{id}", director.getId()))
                .andExpect(status().isNoContent());
    }
}
