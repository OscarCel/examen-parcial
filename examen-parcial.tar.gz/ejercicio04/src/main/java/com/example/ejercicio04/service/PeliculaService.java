package com.example.ejercicio04.service;

import com.example.ejercicio04.model.Pelicula;
import com.example.ejercicio04.repository.PeliculaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PeliculaService {

    @Autowired
    private PeliculaRepository peliculaRepository;

    public List<Pelicula> listarPeliculas() {
        return peliculaRepository.findAll();
    }

    public Optional<Pelicula> leerPelicula(Long id) {
        return peliculaRepository.findById(id);
    }

    public Pelicula crearPelicula(Pelicula pelicula) {
        return peliculaRepository.save(pelicula);
    }

    public Optional<Pelicula> actualizarPelicula(Long id, Pelicula pelicula) {
        return peliculaRepository.findById(id).map(existingPelicula -> {
            pelicula.setId(id);
            return peliculaRepository.save(pelicula);
        });
    }

    public void borrarPelicula(Long id) {
        peliculaRepository.deleteById(id);
    }
}
