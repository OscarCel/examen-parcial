package com.example.ejercicio03.controller;

import com.example.ejercicio03.model.Teclado;
import com.example.ejercicio03.model.Pantalla;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/telefono")
public class TelefonoController {
    private Teclado teclado;
    private Pantalla pantalla;

    public TelefonoController(Teclado teclado, Pantalla pantalla) {
        this.teclado = teclado;
        this.pantalla = pantalla;
    }

    @PostMapping("/encender-apagar")
    public String encenderApagar() {
        teclado.EncenderApagar("Power");
        return pantalla.mostrar();
    }

    @PostMapping("/llamar-colgar")
    public String llamarColgar(@RequestParam String accion) {
        teclado.LlamarColgar(accion);
        return pantalla.mostrar();
    }

    @GetMapping("/estado")
    public String estado() {
        return pantalla.mostrar();
    }
}
