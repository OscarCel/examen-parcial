package com.example.ejercicio01.model;

public class Coche implements ConPuertas {
    private String nombre;
    private boolean puertasAbiertas;

    public Coche(String nombre) {
        this.nombre = nombre;
        this.puertasAbiertas = false;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String descripcion() {
        return "Coche: " + nombre;
    }

    @Override
    public void abrirPuertas() {
        puertasAbiertas = true;
        System.out.println("Puertas del coche abiertas.");
    }

    @Override
    public void cerrarPuertas() {
        puertasAbiertas = false;
        System.out.println("Puertas del coche cerradas.");
    }

    @Override
    public String estadoPuertas() {
        return puertasAbiertas ? "Puertas abiertas" : "Puertas cerradas";
    }
}

