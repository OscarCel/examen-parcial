package com.example.ejercicio01.model;

public interface ConPuertas {
    void abrirPuertas();
    void cerrarPuertas();
    String estadoPuertas();
}

