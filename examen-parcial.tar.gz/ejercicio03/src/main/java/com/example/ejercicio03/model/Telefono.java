package com.example.ejercicio03.model;

public class Telefono {
    private boolean encendido = false;
    private boolean enLlamada = false;
    private String numeroActual = "";

    public boolean isEncendido() {
        return encendido;
    }

    public void encender() {
        this.encendido = true;
    }

    public void apagar() {
        this.encendido = false;
        if (enLlamada) {
            colgar();
        }
    }

    public boolean isEnLlamada() {
        return enLlamada;
    }

    public void marcarNumero(String numero) {
        if (encendido) {
            this.numeroActual = numero;
        }
    }

    public void llamar() {
        if (encendido && !numeroActual.isEmpty()) {
            this.enLlamada = true;
        }
    }

    public void colgar() {
        this.enLlamada = false;
        this.numeroActual = "";
    }

    public String getNumeroActual() {
        return numeroActual;
    }
}