package com.example.ejercicio03.model;

public class Teclado {
    private Telefono telefono;

    public Teclado(Telefono telefono) {
        this.telefono = telefono;
    }

    public void EncenderApagar(String tecla) {
        if (tecla.equals("Power") && telefono.isEncendido() == false) {
            telefono.encender();
        } else if (tecla.equals("Power") && telefono.isEncendido() == true) {
            telefono.apagar();
        }
    }
    
    public void LlamarColgar(String llamada){
        if (llamada.equals("Llamar")) {
            telefono.llamar();
        } else if (llamada.equals("Colgar")) {
            telefono.colgar();
        } else {
            telefono.marcarNumero(llamada);
        }
    }
}