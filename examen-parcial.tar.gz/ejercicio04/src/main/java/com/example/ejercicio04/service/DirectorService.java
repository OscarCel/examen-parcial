package com.example.ejercicio04.service;

import com.example.ejercicio04.model.Director;
import com.example.ejercicio04.repository.DirectorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DirectorService {

    @Autowired
    private DirectorRepository directorRepository;

    public List<Director> listarDirectores() {
        return directorRepository.findAll();
    }

    public Optional<Director> leerDirector(Long id) {
        return directorRepository.findById(id);
    }

    public Director crearDirector(Director director) {
        return directorRepository.save(director);
    }

    public Optional<Director> actualizarDirector(Long id, Director director) {
        return directorRepository.findById(id).map(existingDirector -> {
            director.setId(id);
            return directorRepository.save(director);
        });
    }

    public void borrarDirector(Long id) {
        directorRepository.deleteById(id);
    }
}
