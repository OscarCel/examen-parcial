package com.example.ejercicio04.controller;

import com.example.ejercicio04.model.Director;
import com.example.ejercicio04.model.Pelicula;
import com.example.ejercicio04.service.PeliculaService;
import com.example.ejercicio04.service.DirectorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/peliculas")
public class PeliculaController {

    @Autowired
    private PeliculaService peliculaService;

    @Autowired
    private DirectorService directorService;

    @GetMapping
    public List<Pelicula> listarPeliculas() {
        return peliculaService.listarPeliculas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pelicula> leerPelicula(@PathVariable Long id) {
        Optional<Pelicula> pelicula = peliculaService.leerPelicula(id);
        if (pelicula.isPresent()) {
            return new ResponseEntity<>(pelicula.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Pelicula> crearPelicula(@Validated @RequestBody Pelicula pelicula) {
        Optional<Director> director = directorService.leerDirector(pelicula.getDirector().getId());
        if (!director.isPresent()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        pelicula.setDirector(director.get());
        Pelicula savedPelicula = peliculaService.crearPelicula(pelicula);
        return new ResponseEntity<>(savedPelicula, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pelicula> actualizarPelicula(@PathVariable Long id, @Validated @RequestBody Pelicula pelicula) {
        Optional<Pelicula> updatedPelicula = peliculaService.actualizarPelicula(id, pelicula);
        return updatedPelicula.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrarPelicula(@PathVariable Long id) {
        peliculaService.borrarPelicula(id);
        return ResponseEntity.noContent().build();
    }
}
