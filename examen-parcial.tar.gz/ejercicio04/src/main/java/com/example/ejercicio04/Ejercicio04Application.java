package com.example.ejercicio04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio04Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio04Application.class, args);
	}

}
